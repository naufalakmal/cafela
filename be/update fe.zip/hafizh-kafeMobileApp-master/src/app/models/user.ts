export class UserRequest{
  username: any;
  password: any;
}

export class UserResponse{
  id: any;
  idRole: any;
  password: any;
  tokenKey: any;
  username: any;
  responseMessage: any;
}

export class RegisterUser{

  fullName: any;
  username: any;
  password: any;
  isRole: any;
}
