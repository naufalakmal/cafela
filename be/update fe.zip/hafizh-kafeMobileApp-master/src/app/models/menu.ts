export class Menu{
  id: any;
  namaNemu: any;
  idKategori: any;
  hargaSatuan: any;
  deskripsi: any;
  file: any;
  vol: any;
}
