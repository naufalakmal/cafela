import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transaksi-berhasil',
  templateUrl: './transaksi-berhasil.page.html',
  styleUrls: ['./transaksi-berhasil.page.scss'],
})
export class TransaksiBerhasilPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
